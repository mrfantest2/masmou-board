Masmou Board M1 BuildHub bundle
Branch source: codex/m1-patient-shell
The Gradle launcher scripts in this bundle call BuildHub's installed `gradle`.
Production Android source mirrors the GitHub M1 branch.
Recommended tasks:
  gradle :app-patient:compileDebugKotlin
  gradle :app-patient:lintDebug
  gradle :app-patient:assembleDebug
