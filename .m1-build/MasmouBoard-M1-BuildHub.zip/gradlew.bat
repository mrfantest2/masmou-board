@echo off
setlocal
set "GRADLE_VERSION=8.11.1"
set "BOOT_ROOT=%TEMP%\masmou-gradle-bootstrap"
set "GRADLE_DIR=%BOOT_ROOT%\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%BOOT_ROOT%\gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%GRADLE_DIR%\bin\gradle.bat" (
  if not exist "%BOOT_ROOT%" mkdir "%BOOT_ROOT%"
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile '%GRADLE_ZIP%'; Expand-Archive -LiteralPath '%GRADLE_ZIP%' -DestinationPath '%BOOT_ROOT%' -Force"
  if errorlevel 1 exit /b %errorlevel%
)

call "%GRADLE_DIR%\bin\gradle.bat" %*
exit /b %errorlevel%
